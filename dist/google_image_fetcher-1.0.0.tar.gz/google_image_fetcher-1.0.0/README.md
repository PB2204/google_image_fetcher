# google_image_fetcher

Google Image Fetcher is a Python library that allows you to fetch images from Google Search using the Custom Search JSON API.

## Installation

You can install this library using pip:

```bash
pip install google_image_fetcher
```